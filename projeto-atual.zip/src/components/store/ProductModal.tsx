'use client'

import { useState, useEffect } from 'react'
import { X, Plus, Minus, ShoppingCart } from 'lucide-react'
import { Button } from '@/components/ui/button'
import type { Product, ProductVariant, VariantOption } from '@/types'

type ProductWithDetails = Product & {
  category?: { name: string } | null
  images?: Array<{ id: string; url: string; position: number }>
  variants?: Array<ProductVariant & {
    options: VariantOption[]
  }>
}

type Props = {
  product: ProductWithDetails | null
  isOpen: boolean
  onClose: () => void
  onAddToCart: (product: ProductWithDetails, selectedOptions: Record<string, VariantOption>, quantity: number) => void
  primaryColor: string
}

export default function ProductModal({ product, isOpen, onClose, onAddToCart, primaryColor }: Props) {
  const [selectedImage, setSelectedImage] = useState(0)
  const [selectedOptions, setSelectedOptions] = useState<Record<string, VariantOption>>({})
  const [quantity, setQuantity] = useState(1)

  useEffect(() => {
    if (product) {
      setSelectedImage(0)
      setSelectedOptions({})
      setQuantity(1)
    }
  }, [product])

  if (!isOpen || !product) return null

  const images = product.images?.sort((a, b) => a.position - b.position) || []
  
  // Filter variants that have options
  const validVariants = product.variants?.filter(v => v.options && v.options.length > 0) || []
  const hasVariants = validVariants.length > 0

  const calculatePrice = () => {
    let price = product.price
    Object.values(selectedOptions).forEach(option => {
      if (option.price) {
        price += option.price
      }
    })
    return price
  }

  const canAddToCart = () => {
    if (!hasVariants) return true
    return validVariants.every(variant => selectedOptions[variant.id])
  }

  const handleAddToCart = () => {
    if (!canAddToCart()) return
    onAddToCart(product, selectedOptions, quantity)
    onClose()
  }

  const handleSelectOption = (variantId: string, option: VariantOption) => {
    setSelectedOptions(prev => ({
      ...prev,
      [variantId]: option
    }))
  }

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 animate-in fade-in duration-200">
      <div className="absolute inset-0 bg-black/50 backdrop-blur-sm transition-all" onClick={onClose} />
      <div className="relative bg-white rounded-2xl shadow-xl max-w-4xl w-full max-h-[90vh] overflow-y-auto animate-in zoom-in-95 slide-in-from-bottom-4 duration-300">
        <button
          onClick={onClose}
          className="absolute top-4 right-4 z-10 h-8 w-8 rounded-full bg-white shadow-md flex items-center justify-center hover:bg-gray-100 transition-all hover:scale-110"
        >
          <X className="h-5 w-5 text-gray-600" />
        </button>
        <div className="sticky top-0 bg-white border-b border-gray-100 px-6 py-4 flex items-center justify-between z-10">
          <h2 className="text-xl font-bold text-gray-900">Detalhes do produto</h2>
          <button
            onClick={onClose}
            className="h-9 w-9 rounded-full hover:bg-gray-100 flex items-center justify-center transition-colors"
          >
            <X className="h-5 w-5 text-gray-500" />
          </button>
        </div>

        <div className="p-6">
          <div className="grid md:grid-cols-2 gap-8">
            {/* Images */}
            <div>
              {images.length > 0 ? (
                <>
                  <div className="aspect-square bg-gray-100 rounded-2xl overflow-hidden mb-3">
                    <img
                      src={images[selectedImage]?.url}
                      alt={product.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  {images.length > 1 && (
                    <div className="flex gap-2 overflow-x-auto pb-2">
                      {images.map((img, idx) => (
                        <button
                          key={img.id}
                          onClick={() => setSelectedImage(idx)}
                          className={`h-16 w-16 rounded-lg overflow-hidden shrink-0 border-2 transition-colors ${
                            idx === selectedImage ? 'border-gray-900' : 'border-gray-200'
                          }`}
                        >
                          <img src={img.url} alt="" className="w-full h-full object-cover" />
                        </button>
                      ))}
                    </div>
                  )}
                </>
              ) : (
                <div className="aspect-square bg-gray-100 rounded-2xl flex items-center justify-center">
                  <ShoppingCart className="h-16 w-16 text-gray-300" />
                </div>
              )}
            </div>

            {/* Details */}
            <div className="flex flex-col">
              <h1 className="text-2xl font-bold text-gray-900 mb-2">{product.name}</h1>
              {product.description && (
                <p className="text-gray-600 mb-4">{product.description}</p>
              )}

              <div className="text-3xl font-bold text-gray-900 mb-6">
                {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(calculatePrice())}
              </div>

              {/* Variants */}
              {hasVariants && (
                <div className="space-y-4 mb-6">
                  {validVariants.sort((a, b) => a.position - b.position).map(variant => (
                    <div key={variant.id}>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        {variant.name}
                      </label>
                      <div className="grid grid-cols-2 gap-2">
                        {variant.options?.sort((a, b) => a.position - b.position).map(option => {
                          const isSelected = selectedOptions[variant.id]?.id === option.id
                          return (
                            <button
                              key={option.id}
                              onClick={() => handleSelectOption(variant.id, option)}
                              className={`px-4 py-3 rounded-xl border-2 text-sm font-medium transition-all ${
                                isSelected
                                  ? 'border-gray-900 bg-gray-900 text-white'
                                  : 'border-gray-200 bg-white text-gray-700 hover:border-gray-300'
                              }`}
                            >
                              <div>{option.name}</div>
                              {option.price && option.price > 0 && (
                                <div className="text-xs opacity-75">
                                  +{new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(option.price)}
                                </div>
                              )}
                            </button>
                          )
                        })}
                      </div>
                    </div>
                  ))}
                </div>
              )}

              {/* Quantity */}
              <div className="mb-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Quantidade
                </label>
                <div className="flex items-center gap-3">
                  <button
                    onClick={() => setQuantity(Math.max(1, quantity - 1))}
                    className="h-10 w-10 rounded-xl border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                  >
                    <Minus className="h-4 w-4" />
                  </button>
                  <span className="text-lg font-semibold w-12 text-center">{quantity}</span>
                  <button
                    onClick={() => setQuantity(quantity + 1)}
                    className="h-10 w-10 rounded-xl border border-gray-300 flex items-center justify-center hover:bg-gray-50 transition-colors"
                  >
                    <Plus className="h-4 w-4" />
                  </button>
                </div>
              </div>

              {/* Add to cart */}
              <Button
                onClick={handleAddToCart}
                disabled={!canAddToCart()}
                className="w-full py-4 text-base font-semibold"
                style={{ backgroundColor: canAddToCart() ? primaryColor : undefined }}
              >
                <ShoppingCart className="h-5 w-5" />
                Adicionar ao carrinho
              </Button>

              {!canAddToCart() && hasVariants && (
                <p className="text-sm text-red-500 mt-2 text-center">
                  Selecione todas as opções
                </p>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
