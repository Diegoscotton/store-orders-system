'use client'

import { useState } from 'react'
import { Store as StoreIcon, ShoppingCart } from 'lucide-react'
import BannerCarousel from '@/components/store/BannerCarousel'
import ProductModal from '@/components/store/ProductModal'
import CartDrawer from '@/components/store/CartDrawer'
import { useCart } from '@/contexts/CartContext'
import type { Store, Product, Banner, Category, ProductVariant, VariantOption } from '@/types'

type ProductWithDetails = Product & {
  category?: { name: string } | null
  images?: Array<{ id: string; url: string; position: number }>
  variants?: Array<ProductVariant & {
    options: VariantOption[]
  }>
}

type Props = {
  store: Store
  products: ProductWithDetails[]
  banners: Banner[]
  categories: Category[]
}

function StoreContent({ store, products, banners, categories }: Props) {
  const [selectedProduct, setSelectedProduct] = useState<ProductWithDetails | null>(null)
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [cartAnimation, setCartAnimation] = useState(false)
  const [selectedCategory, setSelectedCategory] = useState<string | null>(null)
  const { addItem, itemCount, openCart } = useCart()

  const primaryColor = store.primary_color || '#000000'

  const handleProductClick = (product: ProductWithDetails) => {
    setSelectedProduct(product)
    setIsModalOpen(true)
  }

  const handleAddToCart = (product: ProductWithDetails, selectedOptions: Record<string, VariantOption>, quantity: number) => {
    addItem(product, selectedOptions, quantity)
    
    // Trigger cart animation
    setCartAnimation(true)
    setTimeout(() => setCartAnimation(false), 600)
  }

  // Filter products by category
  const filteredProducts = selectedCategory
    ? products.filter(p => p.category_id === selectedCategory)
    : products

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white border-b sticky top-0 z-10">
        <div className="max-w-6xl mx-auto px-4 py-4 flex items-center justify-between gap-4">
          <div className="flex items-center gap-4 min-w-0 flex-1">
            {store.logo_url ? (
              <div className="h-12 flex items-center shrink-0">
                <img src={store.logo_url} alt={store.name} className="max-h-full max-w-[200px] object-contain" />
              </div>
            ) : (
              <div className="flex items-center gap-3">
                <div
                  className="h-10 w-10 rounded-xl flex items-center justify-center shrink-0"
                  style={{ backgroundColor: primaryColor }}
                >
                  <StoreIcon className="h-5 w-5 text-white" />
                </div>
                <div className="min-w-0">
                  <h1 className="font-bold text-gray-900 truncate">{store.name}</h1>
                  {store.description && (
                    <p className="text-sm text-gray-500 truncate">{store.description}</p>
                  )}
                </div>
              </div>
            )}
          </div>
          <button 
            onClick={openCart}
            className={`flex items-center gap-2 bg-gray-900 text-white px-4 py-2 rounded-xl text-sm font-medium hover:bg-gray-800 transition-all shrink-0 relative ${
              cartAnimation ? 'scale-110 ring-4 ring-emerald-400' : ''
            }`}
          >
            <ShoppingCart className={`h-4 w-4 transition-transform ${
              cartAnimation ? 'scale-125' : ''
            }`} />
            <span className="hidden sm:inline">Carrinho</span>
            {itemCount > 0 && (
              <span className={`absolute -top-1 -right-1 h-5 w-5 bg-emerald-500 text-white text-xs font-bold rounded-full flex items-center justify-center transition-all ${
                cartAnimation ? 'scale-125 animate-bounce' : ''
              }`}>
                {itemCount}
              </span>
            )}
          </button>
        </div>
      </header>

      {/* Banners */}
      {banners && banners.length > 0 && (
        <div className="max-w-6xl mx-auto px-4 pt-6">
          <BannerCarousel banners={banners} />
        </div>
      )}

      {/* Content */}
      <main className="max-w-6xl mx-auto px-4 py-8">
        {/* Categories */}
        {categories && categories.length > 0 && (
          <div className="flex gap-2 mb-8 overflow-x-auto pb-2">
            <button 
              onClick={() => setSelectedCategory(null)}
              className={`px-4 py-2 rounded-full text-sm font-medium shrink-0 transition-colors ${
                selectedCategory === null
                  ? 'bg-gray-900 text-white'
                  : 'bg-white text-gray-700 border border-gray-200 hover:border-gray-400'
              }`}
            >
              Todos
            </button>
            {categories.map((cat) => (
              <button
                key={cat.id}
                onClick={() => setSelectedCategory(cat.id)}
                className={`px-4 py-2 rounded-full text-sm font-medium shrink-0 transition-colors ${
                  selectedCategory === cat.id
                    ? 'bg-gray-900 text-white'
                    : 'bg-white text-gray-700 border border-gray-200 hover:border-gray-400'
                }`}
              >
                {cat.name}
              </button>
            ))}
          </div>
        )}

        {/* Products Grid */}
        {!filteredProducts || filteredProducts.length === 0 ? (
          <div className="text-center py-20">
            <div className="h-16 w-16 bg-gray-100 rounded-2xl flex items-center justify-center mx-auto mb-4">
              <StoreIcon className="h-8 w-8 text-gray-400" />
            </div>
            <h2 className="text-lg font-semibold text-gray-900 mb-1">Nenhum produto ainda</h2>
            <p className="text-gray-500">Esta loja ainda está sendo montada.</p>
          </div>
        ) : (
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
            {filteredProducts.map((product) => {
              const mainImage = product.images?.sort((a, b) => a.position - b.position)?.[0]?.url

              return (
                <div
                  key={product.id}
                  className="bg-white rounded-2xl border border-gray-100 overflow-hidden shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                  onClick={() => handleProductClick(product)}
                >
                  {/* Image */}
                  <div className="aspect-square bg-gray-100 relative">
                    {mainImage ? (
                      <img src={mainImage} alt={product.name} className="w-full h-full object-cover" />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center">
                        <StoreIcon className="h-10 w-10 text-gray-300" />
                      </div>
                    )}
                    {product.category?.name && (
                      <span className="absolute top-2 left-2 bg-white/90 backdrop-blur-sm text-xs font-medium text-gray-700 px-2 py-1 rounded-full">
                        {product.category.name}
                      </span>
                    )}
                  </div>

                  {/* Info */}
                  <div className="p-4">
                    <h3 className="font-semibold text-gray-900 mb-1 line-clamp-1">{product.name}</h3>
                    {product.description && (
                      <p className="text-xs text-gray-500 mb-3 line-clamp-2">{product.description}</p>
                    )}

                    {/* Price */}
                    <div className="flex items-center justify-between">
                      <span className="text-lg font-bold text-gray-900">
                        {new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(product.price)}
                      </span>
                    </div>

                    {/* Add to cart button */}
                    <button
                      className="w-full mt-3 py-2 rounded-xl text-sm font-medium text-white transition-colors hover:opacity-90"
                      style={{ backgroundColor: primaryColor }}
                      onClick={(e) => {
                        e.stopPropagation()
                        handleProductClick(product)
                      }}
                    >
                      Adicionar
                    </button>
                  </div>
                </div>
              )
            })}
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-gray-200 py-6 mt-8">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <a
            href="https://fosfo.com.br"
            target="_blank"
            rel="noopener noreferrer"
            className="text-sm text-gray-400 hover:text-gray-600 transition-colors"
          >
            Powered by Fosfo
          </a>
        </div>
      </footer>

      {/* Product Modal */}
      <ProductModal
        product={selectedProduct}
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAddToCart={handleAddToCart}
        primaryColor={primaryColor}
      />

      {/* Cart Drawer */}
      <CartDrawer storeSlug={store.slug} primaryColor={primaryColor} />
    </div>
  )
}

export default function StoreClient(props: Props) {
  return <StoreContent {...props} />
}
