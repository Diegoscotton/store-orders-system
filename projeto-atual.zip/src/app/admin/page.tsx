'use client'

import { useState, useEffect } from 'react'
import { useRouter } from 'next/navigation'
import { useAuth } from '@/hooks/useAuth'
import { getDashboardMetrics, type DashboardMetrics } from '@/services/dashboardService'
import { Card, MetricCardSkeleton, Badge } from '@/components/ui'
import { Package, ShoppingCart, Clock, TrendingUp, DollarSign, CheckCircle, Eye } from 'lucide-react'
import { formatCurrency, getTrialDaysLeft } from '@/lib/utils'

const ORDER_STATUS_LABELS: Record<string, string> = {
  pending: 'Pendente',
  accepted: 'Aceito',
  preparing: 'Preparando',
  ready: 'Pronto',
  delivered: 'Entregue',
  cancelled: 'Cancelado',
}

const ORDER_STATUS_COLORS: Record<string, string> = {
  pending: 'bg-amber-100 text-amber-800 border-amber-200',
  accepted: 'bg-blue-100 text-blue-800 border-blue-200',
  preparing: 'bg-purple-100 text-purple-800 border-purple-200',
  ready: 'bg-cyan-100 text-cyan-800 border-cyan-200',
  delivered: 'bg-emerald-100 text-emerald-800 border-emerald-200',
  cancelled: 'bg-gray-100 text-gray-800 border-gray-200',
}

export default function AdminDashboard() {
  const { store, loading: authLoading } = useAuth()
  const router = useRouter()
  const [metrics, setMetrics] = useState<DashboardMetrics | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    if (authLoading) return
    if (!store) {
      setLoading(false)
      return
    }
    loadMetrics()
  }, [store, authLoading])

  async function loadMetrics() {
    if (!store) return
    try {
      const data = await getDashboardMetrics(store.id)
      setMetrics(data)
    } catch (error) {
      console.error('Erro ao carregar métricas:', error)
    } finally {
      setLoading(false)
    }
  }

  if (authLoading || loading) {
    return (
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Dashboard</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => <MetricCardSkeleton key={i} />)}
        </div>
      </div>
    )
  }

  if (!store) {
    return (
      <div className="flex flex-col items-center justify-center py-20">
        <div className="h-16 w-16 bg-gray-100 rounded-2xl flex items-center justify-center mb-4">
          <Package className="h-8 w-8 text-gray-400" />
        </div>
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Nenhuma loja encontrada</h2>
        <p className="text-gray-500 mb-6">Entre em contato com o suporte.</p>
      </div>
    )
  }

  const trialDays = getTrialDaysLeft(store.trial_ends_at)

  const metricCards = [
    { label: 'Total de Pedidos', value: metrics?.totalOrders || 0, icon: ShoppingCart, color: 'text-blue-600 bg-blue-50' },
    { label: 'Receita Total', value: formatCurrency(metrics?.totalRevenue || 0), icon: DollarSign, color: 'text-emerald-600 bg-emerald-50' },
    { label: 'Pendentes', value: metrics?.pendingOrders || 0, icon: Clock, color: 'text-amber-600 bg-amber-50' },
    { label: 'Concluídos', value: metrics?.completedOrders || 0, icon: CheckCircle, color: 'text-purple-600 bg-purple-50' },
  ]

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('pt-BR', {
      day: '2-digit',
      month: '2-digit',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard</h1>
        <p className="text-gray-500 mt-1">Bem-vindo de volta, {store.name}</p>
      </div>

      {/* Trial notice */}
      {trialDays > 0 && trialDays <= 7 && (
        <div className="mb-6 px-4 py-3 bg-amber-50 border border-amber-200 rounded-xl">
          <p className="text-sm text-amber-800">
            Seu período de teste termina em <strong>{trialDays} dia{trialDays > 1 ? 's' : ''}</strong>. Entre em contato para continuar usando.
          </p>
        </div>
      )}

      {/* Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {metricCards.map((m) => (
          <Card key={m.label} className="flex items-center gap-4">
            <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${m.color}`}>
              <m.icon className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500">{m.label}</p>
              <p className="text-2xl font-bold text-gray-900">{m.value}</p>
            </div>
          </Card>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-8">
        {/* Recent Orders */}
        <Card>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-lg font-semibold text-gray-900">Pedidos Recentes</h2>
            <button
              onClick={() => router.push('/admin/orders')}
              className="text-sm text-gray-600 hover:text-gray-900 flex items-center gap-1"
            >
              Ver todos <Eye className="h-4 w-4" />
            </button>
          </div>
          <div className="space-y-3">
            {metrics?.recentOrders && metrics.recentOrders.length > 0 ? (
              metrics.recentOrders.map((order) => (
                <div key={order.id} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">#{order.order_number}</p>
                    <p className="text-sm text-gray-600">{order.customer_name}</p>
                    <p className="text-xs text-gray-500">{formatDate(order.created_at)}</p>
                  </div>
                  <div className="text-right">
                    <p className="font-semibold text-gray-900">{formatCurrency(order.total_amount || order.total || 0)}</p>
                    <Badge className={ORDER_STATUS_COLORS[order.status]}>
                      {ORDER_STATUS_LABELS[order.status]}
                    </Badge>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500 text-center py-8">Nenhum pedido ainda</p>
            )}
          </div>
        </Card>

        {/* Top Products */}
        <Card>
          <h2 className="text-lg font-semibold text-gray-900 mb-4">Produtos Mais Vendidos</h2>
          <div className="space-y-3">
            {metrics?.topProducts && metrics.topProducts.length > 0 ? (
              metrics.topProducts.map((product, index) => (
                <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 bg-emerald-100 rounded-lg flex items-center justify-center">
                      <span className="text-lg font-bold text-emerald-600">#{index + 1}</span>
                    </div>
                    <div>
                      <p className="font-medium text-gray-900">{product.product_name}</p>
                      <p className="text-sm text-gray-600">{product.total_quantity} vendidos</p>
                    </div>
                  </div>
                  <p className="font-semibold text-gray-900">{formatCurrency(product.total_revenue)}</p>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500 text-center py-8">Nenhuma venda ainda</p>
            )}
          </div>
        </Card>
      </div>

      {/* Quick actions */}
      <h2 className="text-lg font-semibold text-gray-900 mb-4">Acesso rápido</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {[
          { label: 'Novo produto', desc: 'Adicione um produto à sua loja', href: '/admin/products/create' },
          { label: 'Ver pedidos', desc: 'Acompanhe os pedidos recebidos', href: '/admin/orders' },
          { label: 'Configurações', desc: 'Personalize sua loja', href: '/admin/settings' },
        ].map((action) => (
          <Card
            key={action.href}
            hover
            className="cursor-pointer"
            onClick={() => router.push(action.href)}
          >
            <h3 className="font-medium text-gray-900">{action.label}</h3>
            <p className="text-sm text-gray-500 mt-1">{action.desc}</p>
          </Card>
        ))}
      </div>
    </div>
  )
}
