import Link from 'next/link'
import {
  Store, ShoppingCart, Package, Settings,
  MessageCircle, BarChart3, ArrowRight, Zap, Shield, Smartphone
} from 'lucide-react'

export default function HomePage() {
  return (
    <div className="min-h-screen bg-white">
      {/* Navbar */}
      <nav className="fixed top-0 w-full bg-white/80 backdrop-blur-md border-b border-gray-100 z-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="h-8 w-8 bg-gray-900 rounded-lg flex items-center justify-center">
              <Store className="h-4 w-4 text-white" />
            </div>
            <span className="font-bold text-gray-900">Fosfo Pedidos</span>
          </Link>
          <div className="flex items-center gap-3">
            <Link
              href="/demo"
              className="text-sm text-gray-600 hover:text-gray-900 transition-colors hidden sm:block"
            >
              Ver demo
            </Link>
            <Link
              href="/login"
              className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
            >
              Entrar
            </Link>
            <Link
              href="/register"
              className="bg-gray-900 text-white text-sm font-medium px-4 py-2 rounded-xl hover:bg-gray-800 transition-colors"
            >
              Criar loja grátis
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero */}
      <section className="pt-32 pb-20 px-4 sm:px-6">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 bg-gray-100 text-gray-700 text-sm font-medium px-4 py-1.5 rounded-full mb-6">
            <Zap className="h-3.5 w-3.5" />
            Comece a receber pedidos em minutos
          </div>
          <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 tracking-tight leading-tight mb-6">
            Sua loja online
            <br />
            <span className="text-gray-400">simples e bonita</span>
          </h1>
          <p className="text-lg sm:text-xl text-gray-500 max-w-2xl mx-auto mb-10">
            Crie um catálogo profissional, receba pedidos pelo site e pelo WhatsApp.
            Sem complicação, sem mensalidade para começar.
          </p>
          <div className="flex flex-col sm:flex-row gap-3 justify-center">
            <Link
              href="/register"
              className="inline-flex items-center justify-center gap-2 bg-gray-900 text-white font-medium px-8 py-3.5 rounded-xl hover:bg-gray-800 transition-all text-base"
            >
              Criar minha loja
              <ArrowRight className="h-4 w-4" />
            </Link>
            <Link
              href="/demo"
              className="inline-flex items-center justify-center gap-2 border border-gray-300 text-gray-700 font-medium px-8 py-3.5 rounded-xl hover:bg-gray-50 transition-all text-base"
            >
              Ver demonstração
            </Link>
          </div>
        </div>
      </section>

      {/* How it works */}
      <section className="py-20 px-4 sm:px-6 bg-gray-50">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Como funciona</h2>
            <p className="text-gray-500 text-lg">Três passos para começar a vender online</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              {
                step: '01',
                title: 'Crie sua loja',
                desc: 'Cadastre-se, escolha o nome da loja e personalize com sua marca.',
                icon: Store,
              },
              {
                step: '02',
                title: 'Cadastre produtos',
                desc: 'Adicione fotos, preços, variações e organize por categorias.',
                icon: Package,
              },
              {
                step: '03',
                title: 'Receba pedidos',
                desc: 'Seus clientes fazem pedidos e você gerencia tudo pelo painel.',
                icon: ShoppingCart,
              },
            ].map((item) => (
              <div key={item.step} className="relative">
                <span className="text-6xl font-bold text-gray-100 absolute -top-4 -left-2">{item.step}</span>
                <div className="relative bg-white rounded-2xl p-8 shadow-sm border border-gray-100">
                  <div className="h-12 w-12 bg-gray-900 rounded-xl flex items-center justify-center mb-4">
                    <item.icon className="h-6 w-6 text-white" />
                  </div>
                  <h3 className="text-lg font-semibold text-gray-900 mb-2">{item.title}</h3>
                  <p className="text-gray-500">{item.desc}</p>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-5xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-3">Tudo que você precisa</h2>
            <p className="text-gray-500 text-lg">Funcionalidades pensadas para facilitar sua vida</p>
          </div>
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {[
              { icon: Store, title: 'Loja personalizada', desc: 'Logo, cores e banner com a identidade da sua marca' },
              { icon: Package, title: 'Produtos com variações', desc: 'Tamanhos, sabores, cores — cada um com seu preço' },
              { icon: ShoppingCart, title: 'Carrinho inteligente', desc: 'Seus clientes montam o pedido com facilidade' },
              { icon: MessageCircle, title: 'Pedido por WhatsApp', desc: 'Receba os pedidos direto no seu WhatsApp' },
              { icon: BarChart3, title: 'Painel completo', desc: 'Gerencie produtos, pedidos e métricas em um só lugar' },
              { icon: Smartphone, title: '100% responsivo', desc: 'Funciona perfeitamente no celular e computador' },
            ].map((f) => (
              <div key={f.title} className="p-6 rounded-2xl border border-gray-100 hover:border-gray-200 hover:shadow-sm transition-all">
                <div className="h-10 w-10 bg-gray-100 rounded-xl flex items-center justify-center mb-4">
                  <f.icon className="h-5 w-5 text-gray-700" />
                </div>
                <h3 className="font-semibold text-gray-900 mb-1">{f.title}</h3>
                <p className="text-sm text-gray-500">{f.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-4 sm:px-6">
        <div className="max-w-3xl mx-auto text-center bg-gray-950 rounded-3xl p-12 sm:p-16">
          <h2 className="text-3xl font-bold text-white mb-4">Pronto para começar?</h2>
          <p className="text-gray-400 text-lg mb-8">
            Crie sua loja online agora e comece a receber pedidos hoje mesmo. É grátis para testar.
          </p>
          <Link
            href="/register"
            className="inline-flex items-center gap-2 bg-white text-gray-900 font-medium px-8 py-3.5 rounded-xl hover:bg-gray-100 transition-all text-base"
          >
            Criar minha loja grátis
            <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 px-4 sm:px-6 border-t border-gray-100">
        <div className="max-w-6xl mx-auto flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="h-6 w-6 bg-gray-900 rounded flex items-center justify-center">
              <Store className="h-3 w-3 text-white" />
            </div>
            <span className="text-sm text-gray-500">
              © 2026 Fosfo Pedidos. Todos os direitos reservados.
            </span>
          </div>
          <div className="flex items-center gap-4">
            <Link href="/demo" className="text-sm text-gray-500 hover:text-gray-900 transition-colors">
              Demo
            </Link>
            <Link href="/login" className="text-sm text-gray-500 hover:text-gray-900 transition-colors">
              Login
            </Link>
            <a
              href="https://fosfo.com.br"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-gray-500 hover:text-gray-900 transition-colors"
            >
              Powered by Fosfo
            </a>
          </div>
        </div>
      </footer>
    </div>
  )
}
