export default function MasterSettingsPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-2">Configurações</h1>
      <p className="text-gray-500">Configurações da plataforma — será construído na Fase 5.</p>
    </div>
  )
}
