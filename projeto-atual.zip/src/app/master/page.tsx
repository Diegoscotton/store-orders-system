'use client'

import { useState, useEffect } from 'react'
import { createClient } from '@/lib/supabase'
import { Card, MetricCardSkeleton } from '@/components/ui'
import { Store, Users, ShoppingCart, TrendingUp } from 'lucide-react'

export default function MasterDashboard() {
  const [metrics, setMetrics] = useState({ stores: 0, activeStores: 0, users: 0, orders: 0 })
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    loadMetrics()
  }, [])

  async function loadMetrics() {
    const supabase = createClient()

    const [stores, activeStores, users, orders] = await Promise.all([
      supabase.from('stores').select('*', { count: 'exact', head: true }),
      supabase.from('stores').select('*', { count: 'exact', head: true }).eq('is_active', true),
      supabase.from('profiles').select('*', { count: 'exact', head: true }).eq('role', 'admin'),
      supabase.from('orders').select('*', { count: 'exact', head: true }),
    ])

    setMetrics({
      stores: stores.count || 0,
      activeStores: activeStores.count || 0,
      users: users.count || 0,
      orders: orders.count || 0,
    })
    setLoading(false)
  }

  if (loading) {
    return (
      <div>
        <h1 className="text-2xl font-bold text-gray-900 mb-6">Dashboard Master</h1>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
          {[1, 2, 3, 4].map((i) => <MetricCardSkeleton key={i} />)}
        </div>
      </div>
    )
  }

  const cards = [
    { label: 'Total de lojas', value: metrics.stores, icon: Store, color: 'text-blue-600 bg-blue-50' },
    { label: 'Lojas ativas', value: metrics.activeStores, icon: TrendingUp, color: 'text-emerald-600 bg-emerald-50' },
    { label: 'Usuários', value: metrics.users, icon: Users, color: 'text-purple-600 bg-purple-50' },
    { label: 'Pedidos (global)', value: metrics.orders, icon: ShoppingCart, color: 'text-amber-600 bg-amber-50' },
  ]

  return (
    <div>
      <div className="mb-8">
        <h1 className="text-2xl font-bold text-gray-900">Dashboard Master</h1>
        <p className="text-gray-500 mt-1">Visão geral da plataforma</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {cards.map((m) => (
          <Card key={m.label} className="flex items-center gap-4">
            <div className={`h-12 w-12 rounded-xl flex items-center justify-center ${m.color}`}>
              <m.icon className="h-6 w-6" />
            </div>
            <div>
              <p className="text-sm text-gray-500">{m.label}</p>
              <p className="text-2xl font-bold text-gray-900">{m.value}</p>
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}
