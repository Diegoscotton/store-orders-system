export default function MasterUsersPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-2">Usuários</h1>
      <p className="text-gray-500">Gestão de usuários — será construído na Fase 5.</p>
    </div>
  )
}
