export default function MasterStoresPage() {
  return (
    <div>
      <h1 className="text-2xl font-bold text-gray-900 mb-2">Lojas</h1>
      <p className="text-gray-500">Gestão de lojas — será construído na Fase 5.</p>
    </div>
  )
}
